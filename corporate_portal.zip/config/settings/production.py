from .base import *  # noqa: F401,F403

DEBUG = False

ALLOWED_HOSTS = [
    "cp.leovit.ru",
]

CSRF_TRUSTED_ORIGINS = [
    "https://cp.leovit.ru",
]

SECURE_SSL_REDIRECT = True
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True

SECURE_HSTS_SECONDS = 3600
SECURE_HSTS_INCLUDE_SUBDOMAINS = False
SECURE_HSTS_PRELOAD = False